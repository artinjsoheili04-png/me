# Apartment Finder Website

This is a static apartment search website.

## How to open locally
Double-click `index.html` or open it in a browser.

## How to use
- Search listings by address, landlord, notes, or facilities.
- Filter by rent, bedrooms, location, parking, pet-friendly status, laundry, gym, newest listings, and landlord credibility.
- Paste one or more listing links into the "Add listings by link" section.
- Added links are saved in the browser using localStorage.
- Export listings as CSV or JSON.

## Important
This website does not scrape Craigslist, Facebook Marketplace, or any rental site. It only creates listing cards from links that the user manually pastes.

## How to publish as a website

### Option 1: GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to Settings > Pages.
4. Set the branch to `main`.
5. Save.
6. GitHub will generate a public website link.

### Option 2: Netlify
1. Go to Netlify.
2. Drag and drop this folder into the deploy box.
3. Netlify will create a live website link.

### Option 3: Vercel
1. Create a new Vercel project.
2. Upload or connect this folder.
3. Deploy it as a static site.
